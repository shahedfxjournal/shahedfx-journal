 "use client";

import { useEffect, useMemo, useState } from "react";

type Trade = {
  id:string; symbol:string; side:"BUY"|"SELL"; entry:number; exit:number|null;
  pnl:number; risk_pct:number|null; lot_size:number|null; setup:string|null;
  emotion:string|null; traded_at:string;
};

const seed:Trade[]=[
 {id:"1",symbol:"XAUUSD",side:"BUY",entry:3821.4,exit:3837.9,pnl:165,risk_pct:1,lot_size:.1,setup:"London breakout",emotion:"Calm",traded_at:"2026-10-04"},
 {id:"2",symbol:"EURUSD",side:"SELL",entry:1.1718,exit:1.1699,pnl:190,risk_pct:1,lot_size:.2,setup:"Liquidity sweep",emotion:"Confident",traded_at:"2026-10-03"},
 {id:"3",symbol:"GBPUSD",side:"BUY",entry:1.3452,exit:1.3427,pnl:-125,risk_pct:1,lot_size:.2,setup:"Support retest",emotion:"FOMO",traded_at:"2026-10-02"}
];

export default function Home(){
 const [trades,setTrades]=useState<Trade[]>([]);
 const [open,setOpen]=useState(false);
 const [form,setForm]=useState({symbol:"XAUUSD",side:"BUY",entry:"",exit:"",pnl:"",risk_pct:"1",lot_size:"0.10",setup:"",emotion:"Calm"});

 useEffect(()=>{ const saved=localStorage.getItem("shahedfx-trades"); setTrades(saved?JSON.parse(saved):seed)},[]);
 useEffect(()=>{ if(trades.length) localStorage.setItem("shahedfx-trades",JSON.stringify(trades))},[trades]);

 const stats=useMemo(()=>{
   const pnl=trades.reduce((a,t)=>a+t.pnl,0), wins=trades.filter(t=>t.pnl>0).length;
   const grossWin=trades.filter(t=>t.pnl>0).reduce((a,t)=>a+t.pnl,0);
   const grossLoss=Math.abs(trades.filter(t=>t.pnl<0).reduce((a,t)=>a+t.pnl,0));
   return {pnl,wins,losses:trades.length-wins,winRate:trades.length?wins/trades.length*100:0,pf:grossLoss?grossWin/grossLoss:0,balance:10000+pnl};
 },[trades]);

 function saveTrade(e:React.FormEvent){
   e.preventDefault();
   const t:Trade={id:crypto.randomUUID(),symbol:form.symbol,side:form.side as "BUY"|"SELL",
    entry:Number(form.entry)||0,exit:form.exit?Number(form.exit):null,pnl:Number(form.pnl)||0,
    risk_pct:Number(form.risk_pct)||null,lot_size:Number(form.lot_size)||null,setup:form.setup||null,
    emotion:form.emotion,traded_at:new Date().toISOString().slice(0,10)};
   setTrades(x=>[t,...x]); setOpen(false);
   setForm({...form,entry:"",exit:"",pnl:"",setup:""});
 }
 function remove(id:string){setTrades(x=>x.filter(t=>t.id!==id))}
 return <main>
  <aside><div className="brand">Shahed<span>fx</span> Journal</div>
   <nav>{["▦ Dashboard","＋ Add Trade","☷ Trade History","◔ Analytics","□ Calendar","◉ Psychology","⚙ Settings"].map((x,i)=><button key={x} className={i===0?"active":""} onClick={()=>i===1&&setOpen(true)}>{x}</button>)}</nav>
  </aside>
  <section className="main">
   <header><div><h1>Trading Dashboard</h1><p>Forex & Gold • Track. Review. Improve.</p></div><button className="primary" onClick={()=>setOpen(true)}>＋ Add Trade</button></header>
   <div className="cards">
    <Card label="Account Balance" value={`$${stats.balance.toFixed(2)}`}/>
    <Card label="Total P&L" value={`${stats.pnl>=0?"+":"-"}$${Math.abs(stats.pnl).toFixed(2)}`} cls={stats.pnl>=0?"green":"red"}/>
    <Card label="Win Rate" value={`${stats.winRate.toFixed(1)}%`} cls="gold"/>
    <Card label="Profit Factor" value={stats.pf.toFixed(2)}/>
   </div>
   <div className="two">
    <div className="panel"><h3>Performance Overview</h3><div className="bars">
      {[20,45,32,70,55,88,76,100,91,110].map((h,i)=><div key={i} className={i===7||i===8?"bar pos":"bar"} style={{height:`${Math.min(h,100)}%`}}/> )}</div>
      <div className="chart-note">Equity curve visualization • connect Supabase for live multi-device data</div>
    </div>
    <div className="panel"><h3>Performance</h3><div className="list"><p><span>Total Trades</span><b>{trades.length}</b></p><p><span>Winning Trades</span><b className="green">{stats.wins}</b></p><p><span>Losing Trades</span><b className="red">{stats.losses}</b></p><p><span>Best Pair</span><b className="gold">XAUUSD</b></p></div></div>
   </div>
   <div className="panel"><div className="table-head"><h3>Recent Trades</h3><button className="ghost" onClick={()=>setOpen(true)}>Add trade</button></div>
    <div className="table-wrap"><table><thead><tr><th>Date</th><th>Symbol</th><th>Side</th><th>Entry</th><th>Exit</th><th>Setup</th><th>P&L</th><th></th></tr></thead>
    <tbody>{trades.map(t=><tr key={t.id}><td>{t.traded_at}</td><td><b>{t.symbol}</b></td><td><span className={`badge ${t.side==="BUY"?"buy":"sell"}`}>{t.side}</span></td><td>{t.entry}</td><td>{t.exit??"—"}</td><td>{t.setup??"—"}</td><td className={t.pnl>=0?"green":"red"}>{t.pnl>=0?"+":""}${t.pnl}</td><td><button className="del" onClick={()=>remove(t.id)}>×</button></td></tr>)}</tbody></table></div>
   </div>
  </section>
  {open&&<div className="modal"><form onSubmit={saveTrade} className="form"><div className="formtop"><h2>Add New Trade</h2><button type="button" className="close" onClick={()=>setOpen(false)}>×</button></div>
   <div className="fields"><Field label="Symbol"><select value={form.symbol} onChange={e=>setForm({...form,symbol:e.target.value})}><option>XAUUSD</option><option>EURUSD</option><option>GBPUSD</option><option>USDJPY</option></select></Field>
   <Field label="Side"><select value={form.side} onChange={e=>setForm({...form,side:e.target.value})}><option>BUY</option><option>SELL</option></select></Field>
   <Field label="Entry"><input required type="number" step="any" value={form.entry} onChange={e=>setForm({...form,entry:e.target.value})}/></Field>
   <Field label="Exit"><input type="number" step="any" value={form.exit} onChange={e=>setForm({...form,exit:e.target.value})}/></Field>
   <Field label="Lot Size"><input type="number" step="0.01" value={form.lot_size} onChange={e=>setForm({...form,lot_size:e.target.value})}/></Field>
   <Field label="Risk %"><input type="number" step="0.1" value={form.risk_pct} onChange={e=>setForm({...form,risk_pct:e.target.value})}/></Field>
   <Field label="P&L ($)"><input required type="number" step="any" value={form.pnl} onChange={e=>setForm({...form,pnl:e.target.value})}/></Field>
   <Field label="Emotion"><select value={form.emotion} onChange={e=>setForm({...form,emotion:e.target.value})}><option>Calm</option><option>Confident</option><option>Fearful</option><option>FOMO</option><option>Revenge</option></select></Field>
   <Field label="Setup" full><input value={form.setup} placeholder="Liquidity sweep, breakout..." onChange={e=>setForm({...form,setup:e.target.value})}/></Field></div>
   <div className="actions"><button type="button" className="ghost" onClick={()=>setOpen(false)}>Cancel</button><button className="primary">Save Trade</button></div>
  </form></div>}
 </main>
}
function Card({label,value,cls=""}:{label:string,value:string,cls?:string}){return <div className="card"><small>{label}</small><strong className={cls}>{value}</strong></div>}
function Field({label,children,full=false}:{label:string,children:React.ReactNode,full?:boolean}){return <label className={full?"field full":"field"}><small>{label}</small>{children}</label>}
