import "./globals.css"; import type {Metadata} from "next";
export const metadata:Metadata={title:"Shahedfx Journal",description:"Forex & Gold Trading Journal"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
