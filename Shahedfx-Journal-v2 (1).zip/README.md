# Shahedfx Journal v2

## What is included
- Dark Forex & Gold trading dashboard
- Persistent browser storage in the prototype
- Add/delete trades
- Live dashboard calculations
- Supabase/PostgreSQL production schema with Row Level Security

## Run locally
Install Node.js 20+.

```bash
npm install
npm run dev
```

Then open http://localhost:3000

## Supabase
1. Create a Supabase project.
2. Open SQL Editor.
3. Run `supabase/schema.sql`.
4. Add Supabase environment variables when connecting the UI to the database:
   NEXT_PUBLIC_SUPABASE_URL
   NEXT_PUBLIC_SUPABASE_ANON_KEY

The current UI deliberately uses localStorage so it can run immediately without credentials. The next integration step is to replace the localStorage layer with Supabase auth + CRUD.
