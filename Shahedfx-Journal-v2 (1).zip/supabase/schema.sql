create table if not exists public.trades (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  symbol text not null,
  side text not null check (side in ('BUY','SELL')),
  entry numeric not null,
  exit numeric,
  stop_loss numeric,
  take_profit numeric,
  lot_size numeric,
  risk_pct numeric,
  pnl numeric not null default 0,
  setup text,
  emotion text,
  notes text,
  screenshot_url text,
  traded_at date not null default current_date,
  created_at timestamptz not null default now()
);
alter table public.trades enable row level security;
create policy "Users can read own trades" on public.trades for select using (auth.uid()=user_id);
create policy "Users can insert own trades" on public.trades for insert with check (auth.uid()=user_id);
create policy "Users can update own trades" on public.trades for update using (auth.uid()=user_id);
create policy "Users can delete own trades" on public.trades for delete using (auth.uid()=user_id);
create index if not exists trades_user_date_idx on public.trades(user_id,traded_at desc);
